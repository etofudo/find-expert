@extends('layouts.app')

@section('title', 'FindExpert - Nigerian Construction Directory')
@section('description', 'Find professional construction experts, builders, electricians, plumbers and more across Nigeria.')

@section('content')
<!-- Hero Section -->
<section class="hero-section text-white py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold mb-4">Find Construction Experts in Nigeria</h1>
                <p class="lead mb-4">Connect with verified builders, electricians, plumbers, architects and construction professionals across Nigeria.</p>
                <a href="{{ route('experts.index') }}" class="btn btn-light btn-lg">Browse Experts</a>
            </div>
            <div class="col-lg-6">
                <div class="text-center">
                    <i class="fas fa-tools" style="font-size: 8rem; opacity: 0.3;"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Search Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow">
                    <div class="card-body p-4">
                        <h3 class="text-center mb-4">Find Your Expert</h3>
                        <form action="{{ route('experts.index') }}" method="GET">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">What do you need?</label>
                                    <select name="category" class="form-select">
                                        <option value="">All Categories</option>
                                        <option value="builders">Builders</option>
                                        <option value="electricians">Electricians</option>
                                        <option value="plumbers">Plumbers</option>
                                        <option value="architects">Architects</option>
                                        <option value="roofers">Roofers</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Location</label>
                                    <select name="state" class="form-select">
                                        <option value="">All States</option>
                                        <option value="lagos">Lagos</option>
                                        <option value="abuja">Abuja</option>
                                        <option value="rivers">Rivers</option>
                                        <option value="kano">Kano</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="fas fa-search me-2"></i>Search Experts
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Categories Section -->
<section class="py-5">
    <div class="container">
        <h2 class="text-center mb-5">Popular Categories</h2>
        <div class="row g-4">
            <div class="col-md-3">
                <div class="card expert-card h-100 text-center">
                    <div class="card-body">
                        <i class="fas fa-hammer text-primary mb-3" style="font-size: 3rem;"></i>
                        <h5>Builders</h5>
                        <p class="text-muted">Construction and building contractors</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card expert-card h-100 text-center">
                    <div class="card-body">
                        <i class="fas fa-bolt text-warning mb-3" style="font-size: 3rem;"></i>
                        <h5>Electricians</h5>
                        <p class="text-muted">Electrical installation and repair</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card expert-card h-100 text-center">
                    <div class="card-body">
                        <i class="fas fa-wrench text-info mb-3" style="font-size: 3rem;"></i>
                        <h5>Plumbers</h5>
                        <p class="text-muted">Plumbing services and repairs</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card expert-card h-100 text-center">
                    <div class="card-body">
                        <i class="fas fa-drafting-compass text-success mb-3" style="font-size: 3rem;"></i>
                        <h5>Architects</h5>
                        <p class="text-muted">Design and architectural services</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="py-5 bg-primary text-white">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-3">
                <h3 class="fw-bold">{{ $stats['total_experts'] }}+</h3>
                <p>Verified Experts</p>
            </div>
            <div class="col-md-3">
                <h3 class="fw-bold">{{ $stats['total_states'] }}+</h3>
                <p>States Covered</p>
            </div>
            <div class="col-md-3">
                <h3 class="fw-bold">{{ $stats['total_categories'] }}+</h3>
                <p>Service Categories</p>
            </div>
            <div class="col-md-3">
                <h3 class="fw-bold">100%</h3>
                <p>Verified Professionals</p>
            </div>
        </div>
    </div>
</section>
@endsection

@extends('layouts.app')

@section('title', $expert->name . ' - FindExpert')

@section('content')
<div class="container py-5">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                @if($expert->profile_image)
                    <img src="{{ $expert->profile_image }}" class="card-img-top" alt="{{ $expert->name }}" style="height: 300px; object-fit: cover;">
                @else
                    <div class="card-img-top bg-light d-flex align-items-center justify-content-center" style="height: 300px;">
                        <i class="fas fa-user fa-4x text-muted"></i>
                    </div>
                @endif
                <div class="card-body">
                    <h4>{{ $expert->name }}</h4>
                    <p class="text-muted">{{ $expert->category->name ?? 'General Contractor' }}</p>
                    
                    @if($expert->rating > 0)
                        <div class="mb-3">
                            @for($i = 1; $i <= 5; $i++)
                                <i class="fas fa-star {{ $i <= $expert->rating ? 'text-warning' : 'text-muted' }}"></i>
                            @endfor
                            <span class="ms-2">{{ $expert->rating }}/5 ({{ $expert->total_reviews }} reviews)</span>
                        </div>
                    @endif

                    <div class="mb-3">
                        <h6>Contact Information</h6>
                        @if($expert->phone)
                            <p><i class="fas fa-phone me-2"></i>{{ $expert->phone }}</p>
                        @endif
                        @if($expert->email)
                            <p><i class="fas fa-envelope me-2"></i>{{ $expert->email }}</p>
                        @endif
                        @if($expert->website)
                            <p><i class="fas fa-globe me-2"></i><a href="{{ $expert->website }}" target="_blank">Visit Website</a></p>
                        @endif
                    </div>

                    <div class="mb-3">
                        <h6>Location</h6>
                        <p><i class="fas fa-map-marker-alt me-2"></i>{{ $expert->address }}</p>
                        <p class="text-muted">{{ $expert->state->name ?? 'Lagos' }}{{ $expert->lga ? ', ' . $expert->lga->name : '' }}</p>
                    </div>

                    <div class="d-grid gap-2">
                        @if($expert->phone)
                            <a href="tel:{{ $expert->phone }}" class="btn btn-primary">
                                <i class="fas fa-phone me-2"></i>Call Now
                            </a>
                        @endif
                        @if($expert->email)
                            <a href="mailto:{{ $expert->email }}" class="btn btn-outline-primary">
                                <i class="fas fa-envelope me-2"></i>Send Email
                            </a>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5>About {{ $expert->name }}</h5>
                </div>
                <div class="card-body">
                    <p>{{ $expert->description }}</p>
                    
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <h6>Service Category</h6>
                            <span class="badge bg-primary">{{ $expert->category->name ?? 'General Contractor' }}</span>
                        </div>
                        <div class="col-md-6">
                            <h6>Status</h6>
                            <span class="badge bg-{{ $expert->status === 'active' ? 'success' : 'secondary' }}">
                                {{ ucfirst($expert->status) }}
                            </span>
                        </div>
                    </div>

                    @if($expert->data_source)
                        <div class="mt-3">
                            <small class="text-muted">
                                <i class="fas fa-info-circle me-1"></i>
                                Data source: {{ ucfirst(str_replace('_', ' ', $expert->data_source)) }}
                            </small>
                        </div>
                    @endif
                </div>
            </div>

            <!-- Gallery -->
            @if($expert->galleries->count() > 0)
                <div class="card mt-4">
                    <div class="card-header">
                        <h5>Project Gallery</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-2">
                            @foreach($expert->galleries as $gallery)
                                <div class="col-md-4">
                                    <img src="{{ $gallery->image_url }}" class="img-fluid rounded" alt="Project image">
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection
